import { Component } from '@angular/core';

@Component({
  selector: 'customer-app-tabs',
  templateUrl: 'customer-tabs.page.html',
  styleUrls: ['customer-tabs.page.scss']
})
export class CustomerTabsPage {

  constructor() {}

}
